<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;
use GuzzleHttp\RequestOptions;

$httpClient = new Client([
    RequestOptions::VERIFY => false
]);

echo "Author: SampanBuruk \n";
// Get the URL from user input
$url = readline("Enter the URL: ");

// Get the minimum and maximum page numbers from user input
$minPage = intval(readline("Enter the minimum page number to scrape: "));
$maxPage = intval(readline("Enter the maximum page number to scrape: "));

libxml_use_internal_errors(true);

// Open a file handle for writing
$fileHandle = fopen('output.txt', 'w');

for ($page = $minPage; $page <= $maxPage; $page++) {
    $response = $httpClient->get($url . '/' . $page);
    $htmlString = (string) $response->getBody();

    $doc = new DOMDocument();
    $doc->loadHTML($htmlString);
    $xpath = new DOMXPath($doc);

    $personElements = $xpath->query('//tr/td[@class="col-4"]/b');
    $positionElements = $xpath->query('//tr/td[@class="col-3"][1]');
    $emailElements = $xpath->query('//tr/td[@class="col-3"][2]');
    $noTelElements = $xpath->query('//tr/td[@class="col-2"]' );
    $extractedName = [];
    $extractedPosition = [];
    $extractedEmail = [];
    $extractedNoTels = [];

    foreach ($personElements as $index => $personElement) {
        $extractedName[$index] = $personElement->textContent;
    }

    foreach ($positionElements as $index => $positionElement) {
        $extractedPosition[$index] = $positionElement->textContent;
    }

    foreach ($emailElements as $index => $emailElement) {
        $email = $emailElement->textContent;
        $extractedEmail[$index] = $email . '@jpm.gov.my';
    }

    foreach ($noTelElements as $index => $noTelElement) {
        $noTel = $noTelElement->textContent;
        $extractedNoTel[$index] ="03" . $noTel;
    }

    for ($i = 0; $i < count($extractedName); $i++) {
        $output = "Name: " . $extractedName[$i] . PHP_EOL;
        $output .= "Position: " . $extractedPosition[$i] . PHP_EOL;
        $output .= "Email: " . $extractedEmail[$i] . PHP_EOL;
        $output .= "No Tel: " . $extractedNoTel[$i] . PHP_EOL;
        $output .= PHP_EOL;

        // Write the output to the file
        fwrite($fileHandle, $output);
    }
}

// Close the file handle
fclose($fileHandle);

echo "Scraping completed. Output written to output.txt file." . PHP_EOL;
?>
